# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Koordinator vs Eksekutor

Satu agen tidak mengerjakan semuanya sendiri. Pekerjaan dibagi sesuai
spesialisasi — definisi tertulisnya ada di `~/workspace/agents/ROSTER.md`
dan brief tiap spesialis di `~/workspace/agents/<slug>.md`.

### Koordinator (agen utama = saya)
- Rencana, brief, dispatch, verifikasi, serahkan ke user.
- TIDAK mengerjakan pekerjaan berat langsung (riset panjang, tulis naskah
  penuh, render video, bangun aplikasi) — itu didelegasikan.
- Brief ke eksekutor harus mandiri (self-contained): tugas, hasil yang
  diinginkan, batasan, dan SEMUA fakta yang dibutuhkan. Spesialis tidak
  mewarisi transkrip koordinator.
- Hasil spesialis diverifikasi dulu (sendiri atau via `qa`) sebelum
  diserahkan ke user. Jangan teruskan hasil mentah.
- Pekerjaan browser live (login, klik, form, beli), artifact, dan bicara
  langsung ke user tetap di koordinator.

### Eksekutor (subagen spesialis)
- Brief sempit, satu hasil, laporkan kembali ke koordinator.
- Spesialis yang ada: `riset`, `naskah`, `renderer`, `builder`, `qa`,
  `ops`, `gaya`, `seo`, `analis`, `cuan`, `gambar`, `microstock`, `pod`
  (lihat ROSTER.md).

### Hemat token (skill: `token-efficiency`)
- Semua agen — koordinator dan eksekutor — mengikuti skill
  `~/workspace/custom-skills/token-efficiency/SKILL.md`: brief pendek
  (di bawah 500 kata, tunjuk path file bukan tempel isi), baca
  tertarget (grep dulu, baca per baris), panggil tool sekali dan
  paralel, jangan polling, laporan singkat berisi fakta + path +
  link, verifikasi dengan sampel bukan mengulang seluruh cek.
- Paralel hanya bila independen (tidak baca/tulis file yang sama, tidak
  saling menunggu). Berurutan bila ada ketergantungan
  (mis. `naskah` → `renderer` → `qa`).
- Spesialis tidak bicara ke user; butuh keputusan user = tulis sebagai
  pertanyaan terbuka di laporan.

### Metode gaya video (dari video @digitalmarketingid, Threads 14 Nov 2026)
- Pola gaya video disimpan di file desain (`style-guide.md` + `style-lock-hari-*.md`
  di `video-gaya-baru/`), BUKAN dijelaskan ulang tiap kali.
- Setiap koreksi user atas video dicatat jadi ATURAN TETAP di style-guide
  (§9–§11) dan di skill `inside-your-mind-video-style` (§8) — jangan
  mengoreksi hal yang sama dua kali.
- Semua aturan gaya terkumpul di SATU file skill:
  `~/workspace/custom-skills/inside-your-mind-video-style/SKILL.md`
  ("buku panduan gaya video") — agen baru baca file itu dulu sebelum produksi.
- Engine video TIDAK diganti ke Remotion: pipeline Python + ffmpeg
  (`render_new.py`) sudah teruji di 8+ video; video referensi itu sendiri tidak
  memberi langkah instalasi, dan komentatornya pun gagal pasang Remotion.
  Yang diterapkan adalah ALURNYA (file desain + aturan tetap + file skill),
  bukan tool-nya.

### Bala bantuan eksternal di VM ini (fakta, cek 2026-11-16)
- HANYA Codex CLI yang terpasang: `/opt/<user>-image/bin/codex`,
  v0.164.0-alpha.9. Status loginnya BELUM TERVERIFIKASI — jangan klaim ia
  bisa jalan sampai ada tes yang lolos.
- Grok / Antigravity / Gemini / Claude CLI TIDAK terpasang di VM.
- Antigravity (IDE Google di laptop Windows user) terhubung lewat JEMBATAN
  GITHUB: repo Git lokal + repo privat di akun GitHub user (<user>),
  bukan koneksi langsung. Membuat repo itu butuh persetujuan user.
- Aturan: jangan pernah klaim agen eksternal mengerjakan sesuatu kecuali
  outputnya benar-benar ada di tangan.
- Emulator Android TIDAK BISA di VM ini (dicek 2026-11-17 05:30): BlueStacks/
  LDPlayer hanya Windows/Mac; Waydroid/Anbox butuh modul kernel binder +
  ashmem + /dev/kvm — ketiganya tidak ada — dan RAM bebas tinggal ~600MB.
  Jadi upload Shopee Video tetap lewat HP user, atau emulator di laptop
  Windows user sendiri. Yang bisa Muse siapkan: edit video, caption,
  hashtag, dan link produk, supaya langkah di HP tinggal upload.
- Mirror HP ke laptop user (scrcpy/Phone Link) TIDAK memberi Muse kendali:
  layar laptop user tidak terlihat oleh browser cloud Muse. Mirroring hanya
  memudahkan USER mengendalikan HP-nya dari laptop — upload tetap ditekan
  user sendiri.

## Aturan dari kesalahan + yang berhasil (Fanpage affiliate, 21 Nov 2026)
Ditulis atas permintaan user 21 Nov 19:41: "biar enggak lupa mulu kesalahan
tadi — tandai sebagai aturan, dan yang berhasil juga ditandai."

### JANGAN diulangi (kesalahan)
- Postingan carousel JANGAN cuma 2 kartu. Tiap postingan = 5 KARTU, 5 gambar
  produk beda-beda (bukan 1 foto diulang). Carousel butuh minimal 2 foto —
  itu syarat minimum, bukan target.
- JANGAN tampilkan harga di kartu, judul kartu (priceText dikosongkan),
  atau caption. Harga bisa berubah/basi dan memancing komen "Bohong".
- JANGAN pakai caption hasil generate panel (nama produk + "Geser
  kartunya..."). Caption HARUS gaya penasaran ala user ("Sellernya lagi
  sedekah apa ya, murce bener sebagus ini"), kalimat divariasikan, ajakan
  klik ikut cara Cantik Tanpa Drama tapi diedit lagi biar tidak sama persis.
- JANGAN taruh link Shopee mentah di caption. Link HARUS di dalam gambar
  (kartu yang diklik), lewat supplieronlineshop.web.id.
- JANGAN kirim carousel TANPA link induk — Meta menolaknya (error #194;
  gagal 20:35, 20:44, 20:49). Link induk =
  https://supplieronlineshop.web.id/aff-indo.php, jadikan LINK UTAMA untuk
  semua postingan (keputusan user 21 Nov 20:47: "jadiin utama", "semuanya
  link-nya itu"). CATATAN: aff-indo.php milih produk ACAK dari pool — dulu
  kartu produk dikunci pakai rotasi.php?i=N; user 20:23 dan 20:47 tetap
  memilih aff-indo.php sebagai tujuan klik/link utama.
- JANGAN klaim promo/diskon sebelum dicek live di Shopee saat itu juga.
  (Klaim "Gratis Ongkir XTRA tanpa min. belanja" dan "voucher 12%" ternyata
  TIDAK terverifikasi — jangan dipakai.)
- JANGAN anggap postingan terkirim = postingan hidup. Selalu verifikasi
  lewat daftar postingan Page + baca balik post-nya (post demo Converse
  19:27 "terkirim" tapi 404 saat dibaca balik; postingan spatula 18:25
  juga hilang dari daftar).
- JANGAN andalkan URL foto remote-storage untuk jangka panjang — kedaluwarsa
  (kartu promo ~23 Nov 18:51 WIB, foto polos ~23 Nov 19:29 WIB). Re-host
  permanen di GoogieHost sebelum dipakai ulang.
- Token dari Graph API Explorer itu SHORT-LIVED. Untuk posting otomatis
  jangka panjang, tukar ke token long-lived (60 hari) atau ambil ulang
  berkala — jangan anggap token sekali simpan berlaku selamanya.
- Stagger di postcatalog TIDAK jalan seperti yang diharapkan (5 postingan
  keluar dalam hitungan detik walau stagger 10 menit) — jangan janjikan
  jeda antar postingan kalau belum terbukti.

### YANG BERHASIL — pertahankan
- Link carousel lewat token BERHASIL: user token (pages_manage_posts) →
  GET /me/accounts → token Halaman → POST /{page-id}/feed dengan parent
  link + child_attachments. Terbukti di Ruang Healing (20 Nov) dan 5
  produk Pojok Hemat Ibu (21 Nov 19:30, terverifikasi di daftar postingan).
- rotasi.php?i=N BERHASIL sebagai link kartu per produk (supplieronlineshop,
  dikunci ke produk itu, sampai ke link affiliate Shopee yang benar).
- Gambar kartu POLOS (foto galeri Shopee apa adanya, tanpa teks "Cek Shopee",
  harga, atau ajakan klik di dalam gambar — seperti Cantik Tanpa Drama, cek
  ulang 21 Nov 19:47). Ajakan "klik gambar" hanya ada di CAPTION. (Koreksi
  user 21 Nov 19:49: "Cek Shopee" di gambar DIBATALKAN, pindah ke caption;
  emoji kaget bervariasi tetap dipakai, di caption.)
- Caption 2 baris gaya Cantik Tanpa Drama (teaser penasaran + "klik gambar")
  adalah model yang terbukti — caption selalu pendek, tanpa harga/link/detail.
- Riset dulu sebelum klaim: cek promo live, cek harga live, cek galeri foto
  live — satu klaim = satu halaman yang dibuka + tanggal cek.
- Pola agen khusus BERHASIL: satu agen satu tugas, brief mandiri di
  ~/workspace/agents/<slug>.md + baris di ROSTER.md (token-fanpage,
  kumpul-link-shopee, grup-fanpage).
- Foto produk dari galeri Shopee (bukan 1 foto utama saja) — importshopeeproducts
  menarik judul/harga/galeri dari halaman produk asli.
- Verifikasi di halaman sebelum langkah yang tidak bisa dibatalkan; dan
  laporkan yang nyangkut duluan, dengan jujur.
